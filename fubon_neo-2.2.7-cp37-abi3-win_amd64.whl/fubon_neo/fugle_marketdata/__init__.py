"""Re-export fugle_marketdata components for backward compatibility"""
from fugle_marketdata import FugleAPIError

__all__ = ['FugleAPIError']
