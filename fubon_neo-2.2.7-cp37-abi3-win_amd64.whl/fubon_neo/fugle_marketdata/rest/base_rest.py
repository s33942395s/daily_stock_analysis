"""Re-export FugleAPIError for backward compatibility with old import paths"""
from fugle_marketdata import FugleAPIError

__all__ = ['FugleAPIError']
